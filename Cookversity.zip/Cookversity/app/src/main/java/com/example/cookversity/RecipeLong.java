package com.example.cookversity;

public class RecipeLong {
}
