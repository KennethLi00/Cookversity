package com.example.cookversity.Entities;

import java.io.Serializable;
//import org.apache.commons.lang.builder.ToStringBuilder;

public class WinePairing implements Serializable
{

    private final static long serialVersionUID = 2774102469609877013L;

//    @Override
//    public String toString() {
//        return new ToStringBuilder(this).toString();
//    }

}