package com.example.cookversity.Entities;

public class RecipeLongResponse {
}
